# A-1 · A-2 · A-3

이 폴더의 파일은 주법 판정, 브랜드 순위, 금지어 검사의 단일 구현입니다. 같은 역할의 함수를 别处에 새로 얹지 말고 여기를 쓰세요.

| 파일 | 역할 |
| --- | --- |
| `Footstrike.ts` | 착지 주법. 바깥 구간 먼저, `view`, `±40°`, 분모는 판정된 착지 |
| `Footstrike.test.ts` | 경계값 15개 (`npm run test:analysis`) |
| `Shoeranking.ts` | `recommendShoes`가 `{ primary, others }`를 한 번에 내림. `N/A`는 `null` |
| `Shoeranking.test.ts` | 순서를 뒤집어도 Nike → Asics → Adidas, 높은 점수를 고름 |
| `../../scripts/check-language.mjs` | `npm run check:language`. 면책은 통과, 실제 위반만 잡고 종료 코드 1 |

## A-1 주법

`angle <= 8`로 미드풋을 먼저 잡으면 `+8`이 미드풋으로 빨려 들어갑니다. 리어풋(`<= -8`)과 포어풋(`>= 8`)을 먼저 걸러냅니다. `Number.isFinite`가 없으면 `NaN`이 모든 비교에서 false가 되어 조용히 미드풋이 됩니다. 정면은 `view: "front"`로 unknown입니다.

## A-2 브랜드

`PRIORITY_BRANDS = ["Nike", "Asics", "Adidas"]`. 주법이 없으면 빈 배열 대신 `kind: "general"`을 돌려 호출부가 `.map()`으로 그냥 지나가지 못하게 합니다. `전체`는 모든 주법 풀에, `미드풋|포어풋`은 두 풀에 들어갑니다.

## A-3 금지어

면책(아닙니다 / 수는 없습니다)은 통과하고, 실제 위반만 실패합니다. CI에 `npm run check:language`를 붙이면 됩니다. 걸린 문구는 예외 목록에 넣지 말고 고칩니다.

## 판정 근거

판정 경계값은 `../../shared/thresholds.yaml` 한 곳에만 있습니다. 값마다 `source` 와
`validation_status` 를 달고, `npm run emit:thresholds` 가 `thresholds.generated.ts` 를
다시 씁니다. YAML 과 생성 파일이 어긋나면 `npm run test:analysis` 가 실패합니다.

`validation_status: withheld` 는 라벨이 아니라 동작입니다. 러닝에서 검증된 기준이
없는 값에는 판정을 붙이지 않고 측정값만 내보냅니다 (`isPublishable`).

`Footstrike.ts` 의 `±8°`, `40°` 는 이 파일이 단독으로 컴파일되어야 해서 숫자를 그대로
두었습니다. 대신 자체 테스트가 YAML 값과 일치하는지 확인합니다.

## 품질 · 배속 · 표시

- 선택한 배속이 보행과 어긋나면 품질을 `poor`로 내리고 접지·반력·주법을 비웁니다.
- 착지 점수는 반력·부하율·무릎만 씁니다. 짧은 접지는 페이스입니다.
- 화면의 접지·체공 시간은 약 30ms 칸으로 보여 줍니다. 케이던스는 놓친 착지를 건너뛴 전형 간격입니다.
- 몸 앞 착지(오버스트라이딩)는 거리만 표시하고 판정하지 않습니다. 임계값이 `withheld`
  이기 때문이며, YAML 에서 상태만 올리면 판정 문구가 그대로 켜집니다.
- 정면은 품질 결함이 아니라 두 번째 모드입니다. `cameraView` 로 갈라지며, 옆모습
  전용(주법·몸 앞 착지·무릎 굽힘)은 비우고 정면 전용(무릎 정렬·골반 기울기)을 냅니다.
  정면에서는 충격 점수의 무릎 항목을 빼고 남은 두 항목을 100점으로 다시 폅니다.
